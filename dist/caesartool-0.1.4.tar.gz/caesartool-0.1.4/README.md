# Caesar Cipher Program

A very simple Python implementation of the Caesar Cipher encryption and decryption algorithm. This program allows you to encrypt and decrypt messages with a shift cipher (Caesar cipher), where each letter is shifted by a given number (key). Encrypt your message, don't get stabbed in the back

## Installation

To install the Caesar Cipher program, you can use `pip`:

```bash
pip install caesar
